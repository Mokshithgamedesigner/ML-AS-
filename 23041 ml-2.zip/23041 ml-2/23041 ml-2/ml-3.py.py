import numpy as np # type: ignore
import pandas as pd # type: ignore
from numpy import linalg # type: ignore
import statistics
import matplotlib.pyplot as plt # type: ignore
import pandas as pd # type: ignore
from sklearn.preprocessing import MinMaxScaler # type: ignore
import seaborn as sns # type: ignore
import pandas as pd # type: ignore
import numpy as np # type: ignore
import matplotlib.pyplot as plt # type: ignore

file_path = r"C:\Users\91900\Desktop\23041 ml-3\23041 ml-3\Lab Session Data.xlsx"
purchase_data = pd.read_excel(file_path, sheet_name="Purchase data")

A = purchase_data[["Candies (#)", "Mangoes (Kg)", "Milk Packets (#)"]].values
C = purchase_data[["Payment (Rs)"]].values

dim_A = A.shape
vec_A = A.shape[1]
rank_A = linalg.matrix_rank(A)
pinv_A = linalg.pinv(A)
x = np.dot(pinv_A, C)

print(dim_A, vec_A, rank_A, x)
purchase_data["Category"] = np.where(purchase_data["Payment (Rs)"] > 200, "RICH", "POOR")
print(purchase_data[["Customer", "Category"]])

stock_data = pd.read_excel(file_path, sheet_name="IRCTC Stock Price")

prices = stock_data.iloc[:, 3]
mean_price = statistics.mean(prices)
var_price = statistics.variance(prices)

wed_prices = stock_data[stock_data.iloc[:, 1] == "Wednesday"].iloc[:, 3]
mean_wed = statistics.mean(wed_prices) if not wed_prices.empty else None

apr_prices = stock_data[pd.to_datetime(stock_data.iloc[:, 0]).dt.month == 4].iloc[:, 3]
mean_apr = statistics.mean(apr_prices) if not apr_prices.empty else None

chg = stock_data.iloc[:, 8]
loss_prob = sum(chg < 0) / len(chg)
profit_wed = sum((chg > 0) & (stock_data.iloc[:, 1] == "Wednesday")) / sum(stock_data.iloc[:, 1] == "Wednesday") if sum(stock_data.iloc[:, 1] == "Wednesday") > 0 else None
cond_prob = profit_wed / (sum(stock_data.iloc[:, 1] == "Wednesday") / len(stock_data)) if profit_wed else None

plt.scatter(stock_data.iloc[:, 1], chg)
plt.xlabel("Day")
plt.ylabel("Chg%")
plt.title("Chg% vs Day")
plt.show()

thyroidData = pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

numericCols = thyroidData.select_dtypes(include=[np.number]).columns
categoricalCols = thyroidData.select_dtypes(exclude=[np.number]).columns

print(thyroidData.dtypes)
print(thyroidData.describe())

thyroidData[numericCols] = thyroidData[numericCols].apply(
    lambda x: x.fillna(x.median() if ((x - x.mean()).abs() > 3 * x.std()).sum() > 0 else x.mean())
)
thyroidData[categoricalCols] = thyroidData[categoricalCols].apply(lambda x: x.fillna(x.mode()[0]))

print(thyroidData.isnull().sum())

scaler = MinMaxScaler()
thyroidData[numericCols] = scaler.fit_transform(thyroidData[numericCols])

print(thyroidData.head())

vec1 = thyroidData.iloc[0, :].astype(bool)
vec2 = thyroidData.iloc[1, :].astype(bool)

f11 = sum(vec1 & vec2)
f00 = sum(~vec1 & ~vec2)
f01 = sum(~vec1 & vec2)
f10 = sum(vec1 & ~vec2)

JC = f11 / (f01 + f10 + f11)
SMC = (f11 + f00) / (f00 + f01 + f10 + f11)

print("Jaccard Similarity:", JC)
print("Simple Matching Coefficient:", SMC)

vec1Full = thyroidData.loc[0, numericCols].values.astype(np.float64)
vec2Full = thyroidData.loc[1, numericCols].values.astype(np.float64)

cosineSim = np.dot(vec1Full, vec2Full) / (np.linalg.norm(vec1Full) * np.linalg.norm(vec2Full))
print("Cosine Similarity:", cosineSim)

simMatrix = np.zeros((20, 20))
for i in range(20):
    for j in range(20):
        v1 = thyroidData.iloc[i, :].astype(bool)
        v2 = thyroidData.iloc[j, :].astype(bool)
        f11 = sum(v1 & v2)
        f00 = sum(~v1 & ~v2)
        f01 = sum(~v1 & v2)
        f10 = sum(v1 & ~v2)
        JC = f11 / (f01 + f10 + f11)
        SMC = (f11 + f00) / (f00 + f01 + f10 + f11)
        cosineSim = np.dot(thyroidData.loc[i, numericCols].values.astype(np.float64), thyroidData.loc[j, numericCols].values.astype(np.float64)) / \
                    (np.linalg.norm(thyroidData.loc[i, numericCols].values.astype(np.float64)) * np.linalg.norm(thyroidData.loc[j, numericCols].values.astype(np.float64)))
        simMatrix[i, j] = (JC + SMC + cosineSim) / 3

plt.figure(figsize=(12, 8))  
sns.heatmap(simMatrix, annot=True, cmap='coolwarm', fmt='.2f', cbar_kws={'label': 'Similarity'}, 
            xticklabels=range(1, 21), yticklabels=range(1, 21), linewidths=0.5)

plt.title('Similarity Matrix of Thyroid Data', fontsize=16)
plt.xlabel('Sample Index', fontsize=14)
plt.ylabel('Sample Index', fontsize=14)

plt.tight_layout()
plt.show()